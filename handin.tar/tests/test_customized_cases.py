"""We encourage you to create your own test cases, which helps
you confirm the correctness of your implementation.

If you are interested, you can write your own tests in this file
and share them with us by including this file in your submission.
Please make the tests "pytest compatible" by starting each test
function name with prefix "test_".

We appreciate it if you can share your tests, which can help
improve this course and the homework. However, please note that
this part is voluntary -- you will not get more scores by sharing
test cases, and conversely, will not get fewer scores if you do
not share.
"""
